package com.example.birdwatchman;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;




    public interface EBirdApi {
        @GET("v2/data/obs/geo/recent/{speciesCode}")
        Call<List<Hotspot>> getNearbyHotspots(
                @Query("latitude") double latitude,
                @Query("longitude") double longitude,
                @Query("maxDistance") int maxDistance,
                @Query("p7gceq17rg0o") String apiKey
        );
    }




