package com.example.birdwatchman;

public class Observation {
    private String observationText;
    private String observationLocation;

    public Observation(String observationText, String observationLocation) {
        this.observationText = observationText;
        this.observationLocation = observationLocation;
    }

    public String getObservationText() {
        return observationText;
    }

    public String getObservationLocation() {
        return observationLocation;
    }
}
