package com.example.birdwatchman;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.example.birdwatchman.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.DirectionsApi;
import com.google.maps.DirectionsApiRequest;
import com.google.maps.GeoApiContext;
import com.google.maps.PendingResult;
import com.google.maps.model.DirectionsResult;
import com.google.maps.model.DirectionsRoute;
import com.google.maps.model.TravelMode;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class Maps extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ImageButton btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettingsActivity();
            }
        });

        Button btnViewObservations = findViewById(R.id.btnViewObservations);
        btnViewObservations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the list of observations
                openObservationsListActivity();
            }
        });
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                // Display an input dialog to capture observation
                showObservationInputDialog(latLng);
            }
        });

        // Check for location permission and enable my location button
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            mMap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
                @Override
                public boolean onMyLocationButtonClick() {

                    return false;
                }
            });

            // Check if the user's location is available before fetching hotspots
            if (mMap.getMyLocation() != null) {
                fetchAndDisplayHotspots(100000);
            }
        } else {
            // Request location permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
    }




    private void drawSampleRoute() {

        GeoApiContext context = new GeoApiContext.Builder()
                .apiKey("AIzaSyASg84h09vSHF9-c302Zd9h0AVQsVu4Cj8")
                .build();

        // Define the origin and destination for the sample route
        LatLng origin = new LatLng(37.7749, -122.4194);
        LatLng destination = new LatLng(34.0522, -118.2437);

        // Create a Directions API request
        DirectionsApiRequest request = DirectionsApi.newRequest(context)
                .origin(new com.google.maps.model.LatLng(origin.latitude, origin.longitude))
                .destination(new com.google.maps.model.LatLng(destination.latitude, destination.longitude))
                .mode(TravelMode.DRIVING);

        // Execute the request asynchronously
        request.setCallback(new PendingResult.Callback<DirectionsResult>() {
            @Override
            public void onResult(DirectionsResult result) {
                DirectionsRoute route = result.routes[0]; // Assuming the first route

                // draw the route on the map
                List<LatLng> path = new ArrayList<>();
                for (com.google.maps.model.LatLng location : route.overviewPolyline.decodePath()) {
                    path.add(new LatLng(location.lat, location.lng));
                }

                PolylineOptions polylineOptions = new PolylineOptions()
                        .addAll(path)
                        .width(10)
                        .color(Color.BLUE);

                mMap.addPolyline(polylineOptions);
            }

            @Override
            public void onFailure(Throwable e) {
                // Handle the error
            }
        });
    }
    private void fetchAndDisplayHotspots(int maxDistance) {
        // Check if the user's location is available before fetching hotspots
        if (mMap.getMyLocation() != null) {

            Retrofit retrofit = RetrofitClient.getClient();
            EBirdApi eBirdApi = retrofit.create(EBirdApi.class);


            Call<List<Hotspot>> call = eBirdApi.getNearbyHotspots(
                    mMap.getMyLocation().getLatitude(),
                    mMap.getMyLocation().getLongitude(),
                    maxDistance,
                    "p7gceq17rg0o"
            );

            call.enqueue(new Callback<List<Hotspot>>() {
                @Override
                public void onResponse(Call<List<Hotspot>> call, Response<List<Hotspot>> response) {
                    if (response.isSuccessful()) {
                        List<Hotspot> hotspots = response.body();
                        // Add markers for hotspots on the map
                        for (Hotspot hotspot : hotspots) {
                            LatLng hotspotLocation = new LatLng(hotspot.getLatitude(), hotspot.getLongitude());
                            mMap.addMarker(new MarkerOptions().position(hotspotLocation).title(hotspot.getName()));
                        }
                    } else {

                    }
                }

                @Override
                public void onFailure(Call<List<Hotspot>> call, Throwable t) {

                }
            });
        }
    }

    private void showObservationInputDialog(final LatLng latLng) {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.observation_input_dialog, null);
        final EditText observationEditText = dialogView.findViewById(R.id.observationEditText);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Observation")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String observationText = observationEditText.getText().toString().trim();
                    if (!TextUtils.isEmpty(observationText)) {
                        // Save the observation to db or your data storage
                        saveObservationToDatabase(latLng, observationText);

                        // Add a marker on the map for the new observation
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title("Bird Observation")
                                .snippet(observationText));
                    } else {
                        Toast.makeText(this, "Observation text cannot be empty", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // method to be used in POE 3 to store in db
    private void saveObservationToDatabase(LatLng latLng, String observationText) {

    }




    private void openSettingsActivity() {
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }



    private void openObservationsListActivity() {
        Intent intent = new Intent(this, ObservationsListActivity.class);
        startActivity(intent);
    }




}
