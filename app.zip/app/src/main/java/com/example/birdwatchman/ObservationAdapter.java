package com.example.birdwatchman;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ObservationAdapter extends RecyclerView.Adapter<ObservationAdapter.ObservationViewHolder> {
    private Context context;
    private List<Observation> observations;

    public ObservationAdapter(Context context, List<Observation> observations) {
        this.context = context;
        this.observations = observations;
    }


    @NonNull
    @Override
    public ObservationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.observation_item, parent, false);
        return new ObservationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ObservationViewHolder holder, int position) {
        Observation observation = observations.get(position);
        holder.bind(observation);
    }

    @Override
    public int getItemCount() {
        return observations.size();
    }

    class ObservationViewHolder extends RecyclerView.ViewHolder {
        private TextView observationTextTextView;
        private TextView observationLocationTextView;

        public ObservationViewHolder(@NonNull View itemView) {
            super(itemView);
            observationTextTextView = itemView.findViewById(R.id.observationTextTextView);
            observationLocationTextView = itemView.findViewById(R.id.observationLocationTextView);
        }

        public void bind(Observation observation) {
            observationTextTextView.setText(observation.getObservationText());
            observationLocationTextView.setText(observation.getObservationLocation());
        }
    }

    // Add the updateData method to update the data for the observationListActivity
    public void updateData(List<Observation> newObservations) {
        observations.clear();
        observations.addAll(newObservations);
        notifyDataSetChanged();
    }
}