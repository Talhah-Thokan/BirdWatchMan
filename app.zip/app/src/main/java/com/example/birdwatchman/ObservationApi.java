package com.example.birdwatchman;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ObservationApi {
    @GET("v2/data/obs/recent")
    Call<List<Observation>> getRecentObservations(@Query("lat") double latitude, @Query("lng") double longitude);
}

