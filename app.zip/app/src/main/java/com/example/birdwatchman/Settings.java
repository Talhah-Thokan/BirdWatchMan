package com.example.birdwatchman;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Settings extends AppCompatActivity {
    private CheckBox checkBoxMetric;
    private CheckBox checkBoxImperial;
    private EditText editTextMaxDistance;
    private Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        checkBoxMetric = findViewById(R.id.checkBoxMetric);
        checkBoxImperial = findViewById(R.id.checkBoxImperial);
        editTextMaxDistance = findViewById(R.id.editTextMaxDistance);
        buttonSave = findViewById(R.id.buttonSave);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save settings based on user preferences
                saveSettings();
            }
        });
    }

    private void saveSettings() {
        // Read user preferences from UI elements
        boolean useMetric = checkBoxMetric.isChecked();
        boolean useImperial = checkBoxImperial.isChecked();
        String maxDistanceStr = editTextMaxDistance.getText().toString();
        int maxDistance = maxDistanceStr.isEmpty() ? 0 : Integer.parseInt(maxDistanceStr);

        // Save these settings to SharedPreferences or your data storage
        // You can use SharedPreferences to store and retrieve user settings.
        SharedPreferences sharedPreferences = getSharedPreferences("BirdWatchmanPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("useMetric", useMetric);
        editor.putBoolean("useImperial", useImperial);
        editor.putInt("maxDistance", maxDistance);
        editor.apply();


    }
}
