package com.example.birdwatchman;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class ObservationsListActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ObservationAdapter adapter;
    private ObservationApi observationApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_observations_list);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the Retrofit instance
        Retrofit retrofit = RetrofitClient.getClient();
        observationApi = retrofit.create(ObservationApi.class);

        // Initialize the adapter
        ArrayList<Observation> observationList = new ArrayList<>();
        adapter = new ObservationAdapter(this, observationList);
        recyclerView.setAdapter(adapter);

        // Request location permission if not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            // Fetch observations for the current location
            fetchObservationsForCurrentLocation();
        }
    }


    private void fetchObservationsForCurrentLocation() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            if (location != null) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();

                // Fetch observations based on latitude and longitude
                Call<List<Observation>> call = observationApi.getRecentObservations(latitude, longitude);
                call.enqueue(new Callback<List<Observation>>() {
                    @Override
                    public void onResponse(Call<List<Observation>> call, Response<List<Observation>> response) {
                        if (response.isSuccessful()) {
                            List<Observation> observations = response.body();
                            adapter.updateData(observations);
                        } else {

                        }
                    }

                    @Override
                    public void onFailure(Call<List<Observation>> call, Throwable t) {

                    }
                });
            } else {

            }
        }
    }

}

